USE inmobiliaria;

-- Limpia registros anteriores e inserta los 56 nuevos
DELETE FROM imagen_propiedad;
ALTER TABLE imagen_propiedad AUTO_INCREMENT = 1;

INSERT INTO imagen_propiedad (id_propiedad, ruta, texto_alt, es_portada, orden) VALUES
(1, 'img/propiedades/buc-0001-1.jpg', 'Portada — Apartamento en Cabecera del Llano', TRUE, 0),
(1, 'img/propiedades/buc-0001-2.jpg', 'Foto 2 — Apartamento en Cabecera del Llano', FALSE, 1),
(1, 'img/propiedades/buc-0001-3.jpg', 'Foto 3 — Apartamento en Cabecera del Llano', FALSE, 2),
(1, 'img/propiedades/buc-0001-4.jpg', 'Foto 4 — Apartamento en Cabecera del Llano', FALSE, 3),
(1, 'img/propiedades/buc-0001-5.jpg', 'Foto 5 — Apartamento en Cabecera del Llano', FALSE, 4),
(1, 'img/propiedades/buc-0001-6.jpg', 'Foto 6 — Apartamento en Cabecera del Llano', FALSE, 5),
(1, 'img/propiedades/buc-0001-7.jpg', 'Foto 7 — Apartamento en Cabecera del Llano', FALSE, 6),
(2, 'img/propiedades/flo-0002-1.jpg', 'Portada — Casa en Cañaveral', TRUE, 0),
(2, 'img/propiedades/flo-0002-2.jpg', 'Foto 2 — Casa en Cañaveral', FALSE, 1),
(2, 'img/propiedades/flo-0002-3.jpg', 'Foto 3 — Casa en Cañaveral', FALSE, 2),
(2, 'img/propiedades/flo-0002-4.jpg', 'Foto 4 — Casa en Cañaveral', FALSE, 3),
(2, 'img/propiedades/flo-0002-5.jpg', 'Foto 5 — Casa en Cañaveral', FALSE, 4),
(2, 'img/propiedades/flo-0002-6.jpg', 'Foto 6 — Casa en Cañaveral', FALSE, 5),
(2, 'img/propiedades/flo-0002-7.jpg', 'Foto 7 — Casa en Cañaveral', FALSE, 6),
(2, 'img/propiedades/flo-0002-8.jpg', 'Foto 8 — Casa en Cañaveral', FALSE, 7),
(2, 'img/propiedades/flo-0002-9.jpg', 'Foto 9 — Casa en Cañaveral', FALSE, 8),
(2, 'img/propiedades/flo-0002-10.jpg', 'Foto 10 — Casa en Cañaveral', FALSE, 9),
(4, 'img/propiedades/buc-0004-1.jpg', 'Portada — Apartamento en Real de Minas', TRUE, 0),
(4, 'img/propiedades/buc-0004-2.jpg', 'Foto 2 — Apartamento en Real de Minas', FALSE, 1),
(4, 'img/propiedades/buc-0004-3.jpg', 'Foto 3 — Apartamento en Real de Minas', FALSE, 2),
(4, 'img/propiedades/buc-0004-4.jpg', 'Foto 4 — Apartamento en Real de Minas', FALSE, 3),
(4, 'img/propiedades/buc-0004-5.jpg', 'Foto 5 — Apartamento en Real de Minas', FALSE, 4),
(4, 'img/propiedades/buc-0004-6.jpg', 'Foto 6 — Apartamento en Real de Minas', FALSE, 5),
(4, 'img/propiedades/buc-0004-7.jpg', 'Foto 7 — Apartamento en Real de Minas', FALSE, 6),
(4, 'img/propiedades/buc-0004-8.jpg', 'Foto 8 — Apartamento en Real de Minas', FALSE, 7),
(4, 'img/propiedades/buc-0004-9.jpg', 'Foto 9 — Apartamento en Real de Minas', FALSE, 8),
(6, 'img/propiedades/gir-0006-1.jpg', 'Portada — Casa campestre en Ruitoque', TRUE, 0),
(6, 'img/propiedades/gir-0006-2.jpg', 'Foto 2 — Casa campestre en Ruitoque', FALSE, 1),
(6, 'img/propiedades/gir-0006-3.jpg', 'Foto 3 — Casa campestre en Ruitoque', FALSE, 2),
(6, 'img/propiedades/gir-0006-4.jpg', 'Foto 4 — Casa campestre en Ruitoque', FALSE, 3),
(6, 'img/propiedades/gir-0006-5.jpg', 'Foto 5 — Casa campestre en Ruitoque', FALSE, 4),
(6, 'img/propiedades/gir-0006-6.jpg', 'Foto 6 — Casa campestre en Ruitoque', FALSE, 5),
(6, 'img/propiedades/gir-0006-7.jpg', 'Foto 7 — Casa campestre en Ruitoque', FALSE, 6),
(6, 'img/propiedades/gir-0006-8.jpg', 'Foto 8 — Casa campestre en Ruitoque', FALSE, 7),
(6, 'img/propiedades/gir-0006-9.jpg', 'Foto 9 — Casa campestre en Ruitoque', FALSE, 8),
(6, 'img/propiedades/gir-0006-10.jpg', 'Foto 10 — Casa campestre en Ruitoque', FALSE, 9),
(8, 'img/propiedades/buc-0008-1.jpg', 'Portada — Oficina en el centro de Bucaramanga', TRUE, 0),
(8, 'img/propiedades/buc-0008-2.jpg', 'Foto 2 — Oficina en el centro de Bucaramanga', FALSE, 1),
(8, 'img/propiedades/buc-0008-3.jpg', 'Foto 3 — Oficina en el centro de Bucaramanga', FALSE, 2),
(8, 'img/propiedades/buc-0008-4.jpg', 'Foto 4 — Oficina en el centro de Bucaramanga', FALSE, 3),
(8, 'img/propiedades/buc-0008-5.jpg', 'Foto 5 — Oficina en el centro de Bucaramanga', FALSE, 4),
(10, 'img/propiedades/buc-0010-1.jpg', 'Portada — Casa en Mutis', TRUE, 0),
(10, 'img/propiedades/buc-0010-2.jpg', 'Foto 2 — Casa en Mutis', FALSE, 1),
(10, 'img/propiedades/buc-0010-3.jpg', 'Foto 3 — Casa en Mutis', FALSE, 2),
(10, 'img/propiedades/buc-0010-4.jpg', 'Foto 4 — Casa en Mutis', FALSE, 3),
(10, 'img/propiedades/buc-0010-5.jpg', 'Foto 5 — Casa en Mutis', FALSE, 4),
(10, 'img/propiedades/buc-0010-6.jpg', 'Foto 6 — Casa en Mutis', FALSE, 5),
(10, 'img/propiedades/buc-0010-7.jpg', 'Foto 7 — Casa en Mutis', FALSE, 6),
(10, 'img/propiedades/buc-0010-8.jpg', 'Foto 8 — Casa en Mutis', FALSE, 7),
(10, 'img/propiedades/buc-0010-9.jpg', 'Foto 9 — Casa en Mutis', FALSE, 8),
(3, 'img/propiedades/buc-0003-1.jpg', 'Portada — Apartaestudio en Provenza', TRUE, 0),
(3, 'img/propiedades/buc-0003-2.jpg', 'Foto 2 — Apartaestudio en Provenza', FALSE, 1),
(5, 'img/propiedades/buc-0005-1.jpg', 'Portada — Local comercial en Sotomayor', TRUE, 0),
(5, 'img/propiedades/buc-0005-2.jpg', 'Foto 2 — Local comercial en Sotomayor', FALSE, 1),
(9, 'img/propiedades/flo-0009-1.jpg', 'Portada — Bodega industrial en Floridablanca', TRUE, 0),
(9, 'img/propiedades/flo-0009-2.jpg', 'Foto 2 — Bodega industrial en Floridablanca', FALSE, 1);

-- Verificación
SELECT p.codigo, COUNT(*) AS fotos, SUM(ip.es_portada) AS portada
FROM propiedad p
LEFT JOIN imagen_propiedad ip ON ip.id_propiedad = p.id_propiedad
GROUP BY p.id_propiedad, p.codigo ORDER BY p.id_propiedad;
